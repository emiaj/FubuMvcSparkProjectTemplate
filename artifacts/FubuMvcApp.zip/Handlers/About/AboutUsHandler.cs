﻿namespace $safeprojectname$.Handlers.About
{
    public class AboutUsHandler
    {
        public AboutUsModel AboutUs(AboutUsInput input)
        {
            return new AboutUsModel();
        }
    }

    public class AboutUsInput
    {
    }

    public class AboutUsModel
    {
    }

}